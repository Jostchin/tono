#!/bin/bash
RUTA1=$(cat ../script/ruta/ruta2.txt)
for FILE in $RUTA1/*.wav;
do
OUTNAME=temp`basename $FILE .wav`.wav; 

sox "$FILE" -r 16000 -b 16 ../out/resaRUIDO/"$OUTNAME"


done

