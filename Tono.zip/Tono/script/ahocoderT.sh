#!/bin/bash
for FILE in ../out/resaCLEAN/*.wav;
do
OUTNAME=`basename $FILE .wav`.csv; 

../ahocoder_64/ahocoder16_64 "$FILE" ../out/f0csv/"$OUTNAME" ../out/2y3/2.csv  ../out/2y3/3.csv

done