#!/bin/bash
RUTA1=$(cat ../script/ruta/ruta1.txt)
for FILE in $RUTA1/*.wav;
do
OUTNAME=temp`basename $FILE .wav`.wav; 

sox "$FILE" -r 16000 -b 16 ../out/resaCLEAN/"$OUTNAME"


done

