#!/bin/bash

pdflatex ../metrica/informe.tex