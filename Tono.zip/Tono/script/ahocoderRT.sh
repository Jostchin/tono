#!//bin/bash
for FILE in ../out/resaRUIDO/*.wav;
do
OUTNAME=`basename $FILE .wav`.csv; 

../ahocoder_64/ahocoder16_64 "$FILE" ../out/f0Rcsv/"$OUTNAME" ../out/2y3/2.csv  ../out/2y3/3.csv

done