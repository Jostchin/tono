#!/bin/bash
for FILE in ../out/f0Rcsv/*.csv;
do
OUTNAME=`basename $FILE .f0`.txt; 

../SPTK/SPTK-3.11/SPTK-3.11/bin/x2x/x2x +fa "$FILE" > ../out/f0txtR/"$OUTNAME"

done