#!/bin/bash
for FILE in ../out/f0csv/*.csv;
do
OUTNAME=`basename $FILE .f0`.txt; 

../SPTK/SPTK-3.11/SPTK-3.11/bin/x2x/x2x +fa "$FILE" > ../out/f0txt/"$OUTNAME"

done
#
#!/bin/bash
#for FILE in ../out/mfcchexadecimal/*.cc;
#do
#OUTNAME=`basename $FILE .cc`.csv; 

#../SPTK/SPTK-3.11/SPTK-3.11/bin/x2x/x2x +fa +a40 "$FILE" > ../out/mfccAhocoder/"$OUTNAME"

#done