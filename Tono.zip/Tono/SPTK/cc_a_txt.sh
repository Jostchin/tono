#!/bin/bash
for FILE in *.cc;
do
OUTNAME=`basename $FILE .cc`.cc.txt; 

/home/jeff/IE499-ProyectoElectrico/SPTK/SPTK-3.8/SPTK-3.8/bin/x2x/x2x +fa +a40 "$FILE" > "$OUTNAME"

done
