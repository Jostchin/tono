#!/usr/bin/env python
# -*- encoding: utf-8 -*-
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import easygui as eg
import easygui
import Signal_Analysis.features.signal as safs
import sys
import os
import subprocess
#
from pylatex import Document, Section, Subsection, Tabular, Math, TikZ, Axis, \
    Plot, Figure, Matrix, Alignat
from pylatex.utils import italic
import webbrowser
###
import threading



def comparalog(ln, ld):
#Verifica que las dos pistas son de igual longitud. Devuelve la longitud en caso de que sean iguales o un False en caso de que sean diferentes
		
	if ln != ld:
		print('Las pistas tienen diferente longitud')
		return False
	
	else:
		
		print('Las pistas tienen la misma longitud',ln)
	return ln

def redimensiona(detectada,ln):
#Esta función se implento para recortar los vectores de difrentes longitudes y asi poder compararlos. 	
	
	redimensionada=np.resize(detectada,ln)
	
	return redimensionada #devuelve un vector de la misma dimension de los datos de la frecuencia natural

def msgEspera(choice,msg):
	title='Análisis de tono'
	eleccion=eg.buttonbox(msg, title, choices)
	if eleccion == choices[0]:
		sys.exit()
	else:
		os.system("evince ../metrica/informe.pdf")
		sys.exit()

def cargadatos(ruta):
#Esta función carga los datos del archivo txt en un vector. Se le pasa la ruta del archivo plano y devuelve un vector con el contenido del archivo.
	vector= np.genfromtxt(ruta)
	return vector

def conversion(natural):
#Esta funcion se encarga de convertir a frecuencia los datos en escala logaritmica de los archivos txt. Devuelve el valor en veces de cada dato en el arreglo.	  
	veces= pow(10,natural)
	return veces

def longitudes(lng):
#Saca la longitud de las listas
	ln = len(lng)
	return ln		

def VDE(natural,detectada,ln,Alatex,Blatex):
#Esta es la metrica de error de decision de voz. Se recorren los vectores natural y detectada, y se compara. Se aumenta el contador de error a registar un fallo en la deteccion.

	i = 0;
	Cantidad_Error = 0;
	print natural
	print detectada
	print ln
	while i < ln: 
		if natural[i]==0: 
			if detectada[i]!=0:
				Cantidad_Error += 1
				print Cantidad_Error
		else:
			if detectada[i]==0:
				Cantidad_Error += 1
		i+=1


	archivo.write('\\section{Resultados de aplicar la métrica VDE}' + '\n\n')
	archivo.write('\\textbf{Los archivos analizados son:}' + '\n\n')
	archivo.write('\\begin{enumerate} \n' + '\\item ' + Alatex + '\n')
	archivo.write('\\item ' + Blatex + '\n' + '\\end{enumerate} \n\n')
	archivo.write('Resultado='+str(Cantidad_Error))

def diferencia(natural,detectada,ln,Alatex,Blatex):
#En esta metrica se recorren ambos vectores natural y detectada haciendo la resta entre ellos y sumando dichas restas para obtener la diferencia entre ellas.

	i=0;
	D=0;
	while i<ln:
		D+= abs(natural[i]-detectada[i])
		
		i+=1
	
	archivo.write('\\section{Resultados de aplicar la métrica Diferencia}' + '\n\n')
	archivo.write('\\textbf{Los archivos analizados son:}' + '\n\n')
	archivo.write('\\begin{enumerate} \n' + '\\item ' + Alatex + '\n')
	archivo.write('\\item ' + Blatex + '\n' + '\\end{enumerate} \n\n')
	archivo.write('Resultado='+str(D))
	
def HNR(natuHz,detecHz,Alatex,Blatex):
#Biblioteca de Paul Boersma que es una metrica.

	hnr=safs.get_HNR( natuHz, 50000 )
	hnr2=safs.get_HNR( detecHz, 50000 )

	archivo.write('\\section{Resultados de aplicar la métrica HNR}' + '\n\n')
	archivo.write('\\textbf{Los archivos analizados son:}' + '\n\n')
	archivo.write('\\begin{enumerate} \n' + '\\item ' + Alatex + '\n')
	archivo.write('\\item ' + Blatex + '\n' + '\\end{enumerate} \n\n')
	archivo.write('Resultado='+str(hnr)+'\n')
	archivo.write('Resultado='+str(hnr2))

if __name__=='__main__':


	archivo=open('informe.tex', 'w')
	archivo.write('\\documentclass{article}\n\\usepackage[utf8]{inputenc}\n\\usepackage{graphicx}\n\\usepackage{float}\n\\title{Sistema de análisis de tono entre conjuntos de señales de habla.}\n\\author{EIE}\n\\begin{document}\n\\maketitle\n')

	

	fieldnames = ['Metrica VDE', 'Criterio de Diferencia', 'Metrica HNR']
	cancelbotton=['None']
	choice = easygui.multchoicebox("Analisis de Tono", "Analisis de Audios", fieldnames)

	title2='Archivo de datos 1'
	title3='Archivo de datos 2'
	print(' ')
	ruta1=eg.diropenbox(title2) #Ruta para audios limpios
	ruta2=eg.diropenbox(title3) #Ruta para audios con ruido

	#Guardar la ruta1 en archivo txt
	file = open("../script/ruta/ruta1.txt", "w")
	file.write(ruta1)
	file.close()
	
	#Guardar la ruta2 en archivo txt
	file = open("../script/ruta/ruta2.txt", "w")
	file.write(ruta2)
	file.close()
	
	os.system("sh ../script/resamplear_para_aho.sh")
	os.system("sh ../script/resamplear_para_ahoRUIDO.sh")
	os.system("sh ../script/ahocoderT.sh")
	os.system("sh ../script/ahocoderRT.sh")
	os.system("sh ../script/f0_a_txt.sh")
	os.system("sh ../script/f0_a_txtRUIDO.sh")

	if choice is None:
		sys.exit()


	if fieldnames[0] in choice:
	#Eleccion de VDE
		rutacsvt="../out/f0txt"
		rutacsvRuidot="../out/f0txtR"
		archivoRuidot = sorted(os.listdir(rutacsvRuidot))
		ind=0
		archivo.write('\\newpage')
		for archivoaudio in sorted(os.listdir(rutacsvt)):
			print(os.path.join(rutacsvt,archivoaudio))
			rutaA=os.path.join(rutacsvt,archivoaudio)
			archivoruidoRuta=archivoRuidot[ind]
			print(os.path.join(rutacsvRuidot,archivoruidoRuta))
			rutaB=os.path.join(rutacsvRuidot,archivoruidoRuta)
			natural = cargadatos(rutaA)	
			detectada = cargadatos(rutaB)
		#	Carga los vectores convetidos a frecuencia en natuHz y detecHz	
			natuHz=conversion(natural)
			detecHz=conversion(detectada)
		#	Se cargan las logitudes en ln y ld	
			ln=longitudes(natural)
			ld=longitudes(detectada)

			#Se carga en r la longitud ln si ambas son iguales o False si son diferentes
			r =comparalog(ln,ld)
			ind=ind+1
			Alatex=rutaA.replace("_", "\\_")
			Blatex=rutaB.replace("_", "\\_")
			VDE(natuHz,detecHz,ln,Alatex,Blatex)			

	if fieldnames[1] in choice:
	#Eleccion de Diferencia
		rutacsvt="../out/f0txt"
		rutacsvRuidot="../out/f0txtR"
		archivoRuidot = sorted(os.listdir(rutacsvRuidot))
		ind=0
		archivo.write('\\newpage')
		for archivoaudio in sorted(os.listdir(rutacsvt)):
			print(os.path.join(rutacsvt,archivoaudio))
			rutaA=os.path.join(rutacsvt,archivoaudio)
			archivoruidoRuta=archivoRuidot[ind]
			print(os.path.join(rutacsvRuidot,archivoruidoRuta))
			rutaB=os.path.join(rutacsvRuidot,archivoruidoRuta)
			natural = cargadatos(rutaA)	
			detectada = cargadatos(rutaB)
		#	Carga los vectores convetidos a frecuencia en natuHz y detecHz	
			natuHz=conversion(natural)
			detecHz=conversion(detectada)
		#	Se cargan las logitudes en ln y ld	
			ln=longitudes(natural)
			ld=longitudes(detectada)

			#Se carga en r la longitud ln si ambas son iguales o False si son diferentes
			r =comparalog(ln,ld)
			ind=ind+1
			Alatex=rutaA.replace("_", "\\_")
			Blatex=rutaB.replace("_", "\\_")
			diferencia(natuHz,detecHz,ln,Alatex,Blatex)

	if fieldnames[2] in choice:
	#Eleccion de HNR
			rutacsvt="../out/f0txt"
			rutacsvRuidot="../out/f0txtR"
			archivoRuidot = sorted(os.listdir(rutacsvRuidot))
			ind=0
			archivo.write('\\newpage')
			for archivoaudio in sorted(os.listdir(rutacsvt)):
				print(os.path.join(rutacsvt,archivoaudio))
				rutaA=os.path.join(rutacsvt,archivoaudio)
				archivoruidoRuta=archivoRuidot[ind]
				print(os.path.join(rutacsvRuidot,archivoruidoRuta))
				rutaB=os.path.join(rutacsvRuidot,archivoruidoRuta)
				natural = cargadatos(rutaA)	
				detectada = cargadatos(rutaB)
			#	Carga los vectores convetidos a frecuencia en natuHz y detecHz	
				natuHz=conversion(natural)
				detecHz=conversion(detectada)
			#	Se cargan las logitudes en ln y ld	
				ln=longitudes(natural)
				ld=longitudes(detectada)

				#Se carga en r la longitud ln si ambas son iguales o False si son diferentes
				r =comparalog(ln,ld)
				ind=ind+1
				Alatex=rutaA.replace("_", "\\_")
				Blatex=rutaB.replace("_", "\\_")
				HNR(natuHz,detecHz,Alatex,Blatex)


archivo.write('\n\\end{document}')
archivo.close()

os.system("sh ../script/latex.sh") # llama script de ltex.sh
choices=['Salir','Ver Resultados']
msg='Análisis Concluido'
threadEspera=threading.Thread(target=msgEspera,args=(choices,msg,))
threadEspera.start()


#FIN#